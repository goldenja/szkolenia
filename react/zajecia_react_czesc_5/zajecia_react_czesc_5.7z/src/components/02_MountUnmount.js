import Clock from './Clock/Clock';

const MountUnmount = () => {
  return <Clock />;
};

export default MountUnmount;
