import './Layout.css';

const Layout = ({ children }) => <div className="Layout">{children}</div>;

export default Layout;
