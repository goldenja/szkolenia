import React from 'react';
import { Provider, useSelector, useDispatch } from 'react-redux'
import { createStore , applyMiddleware , combineReducers} from 'redux'
import { createAction, createReducer, configureStore, current, nanoid } from '@reduxjs/toolkit'
//npm install react-redux


const increment = createAction('increment')
const decrement = createAction('decrement')

const initialState = { value: 0 }

const reducer = createReducer(initialState, (builder) => {
  builder.addCase(increment, (state, action) => { state.value++ });
})


//let store = configureStore({ reducer: reducer })

class Sample1 extends React.Component {

  render() {
    return (
      <Provider store={store}>
        <Counter />
      </Provider>
    );
  }
}
function logger(store) {
  return function wrapDispatchToAddLogging(next) {
    return function dispatchAndLog(action) {
      console.log('dispatching', action.type)
      let result = next(action)
      console.log('next state', store.getState())
      return result
    }
  }
}

function logger2(store) {
  return function wrapDispatchToAddLogging(next) {
    return function dispatchAndLog(action) {
      console.log('dispatching2', action.type)
      let result = next(action)
      console.log('next state2', store.getState())
      return result
    }
  }
}

const asyncFunctionMiddleware = storeAPI => next => action => {
  // If the "action" is actually a function instead...
  if (typeof action === 'function') {
    // then call the function and pass `dispatch` and `getState` as arguments
    return action(storeAPI.dispatch, storeAPI.getState)
  }

  // Otherwise, it's a normal action - send it onwards
  return next(action)
}
 let store = createStore(reducer , applyMiddleware(logger, asyncFunctionMiddleware, logger2));

 const fetchSomeData = (dispatch, getState) => {

  
    // Dispatch an action with the todos we received
    dispatch({ type: 'increment' })

}

store.dispatch(fetchSomeData);

function Counter() {
  const count = useSelector((state) => state.value)
  const dispatch = useDispatch()

  const clickEvent = () => dispatch(increment());



  return (
    <div>
      <div>
        <button
          aria-label="Increment value"
          onClick={clickEvent}>
          Increment
        </button>
        <span>{count}</span>
      </div>
    </div>
  )
}







export default Sample1;