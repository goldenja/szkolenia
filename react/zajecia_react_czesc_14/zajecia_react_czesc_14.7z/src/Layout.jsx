import styled from '@emotion/styled';

export const Layout = styled.div`
  padding: 24px;
`;
